from .ie_api import *
__all__ = ['IENetwork', "IEPlugin", "IECore", "get_version"]
__version__ = get_version()

